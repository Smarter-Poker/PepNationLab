/**
 * GET|POST /api/research/public/v1/match
 * Bearer-token wrapper around the existing match engine.
 */
import { NextResponse, type NextRequest } from 'next/server';

import {
  validateApiKey,
  logApiRequest,
  corsHeaders,
  firstClientIp,
} from '@/lib/research/api-keys';
import { getAllCompounds } from '@/lib/compounds-server';
import {
  scoreCompounds,
  type MatchInput,
  type EvidenceComfort,
  type RiskTolerance,
} from '@/lib/match-engine';

export const dynamic = 'force-dynamic';

const RESEARCH_NOTE =
  'For Research Use Only. This Restates Stored Laboratory Facts And Is Not Dosing Or Medical Advice.';

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders() });
}

async function handle(req: NextRequest, payload: { goal?: string; comfort?: string; risk?: string; limit?: number; exclude_injectables?: boolean; require_long_half_life?: boolean; exclude_slugs?: string[] }) {
  const t0 = Date.now();
  const auth = await validateApiKey(req.headers.get('authorization'));
  if (!auth.ok) {
    return NextResponse.json(
      { error: auth.reason ?? 'unauthorized' },
      { status: auth.reason === 'rate_limited' ? 429 : 401, headers: corsHeaders() },
    );
  }
  const limit = Math.max(1, Math.min(25, Number(payload.limit ?? 10)));
  const compounds = await getAllCompounds();
  const input: MatchInput = {
    goal: payload.goal || 'tissue_repair',
    evidenceComfort: (payload.comfort || 'any') as EvidenceComfort,
    riskTolerance: (payload.risk || 'any') as RiskTolerance,
    excludeInjectables: payload.exclude_injectables,
    requireLongHalfLife: payload.require_long_half_life,
    excludeSlugs: payload.exclude_slugs,
  };
  const data = scoreCompounds(input, compounds, limit);
  const status = 200;
  await logApiRequest(auth.key_id!, '/api/research/public/v1/match', req.method, status, Date.now() - t0, firstClientIp(req));
  return NextResponse.json({ note: RESEARCH_NOTE, results: data?.matches ?? [] }, { status, headers: corsHeaders() });
}

export async function GET(req: NextRequest) {
  return handle(req, {
    goal: req.nextUrl.searchParams.get('goal') ?? '',
    comfort: req.nextUrl.searchParams.get('comfort') ?? '',
    risk: req.nextUrl.searchParams.get('risk') ?? '',
    limit: Number(req.nextUrl.searchParams.get('limit') ?? '10') || 10,
    exclude_injectables: req.nextUrl.searchParams.get('exclude_injectables') === 'true',
    require_long_half_life: req.nextUrl.searchParams.get('require_long_half_life') === 'true',
    exclude_slugs: req.nextUrl.searchParams.getAll('exclude_slugs'),
  });
}

export async function POST(req: NextRequest) {
  let body: { goal?: string; comfort?: string; risk?: string; limit?: number; exclude_injectables?: boolean; require_long_half_life?: boolean; exclude_slugs?: string[] } = {};
  try {
    body = (await req.json()) as typeof body;
  } catch {
    // fall through with empty body
  }
  return handle(req, body);
}
