'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Image from 'next/image';
import { Send, Smile, Paperclip, Image as ImageIcon, FileText, Calendar, Clock, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { useMessengerStore } from '@/stores/messengerStore';
import type { Message, MessageType } from '@/lib/messenger/types';
import EmojiPicker from './EmojiPicker';
import FaqSuggestions from './FaqSuggestions';
import ReplyChip from './ReplyChip';
import AttachMenu from './AttachMenu';
import VoiceRecorder from './VoiceRecorder';
import GifPicker from './GifPicker';
import TemplatesMenu from './TemplatesMenu';
import ExpiryPicker from './ExpiryPicker';
import { vibrateLight, vibrateMedium, playSendSound } from '@/lib/messenger/haptics';

interface Props {
  conversationId: string;
  selfId: string;
  replyTo: Message | null;
  onClearReply: () => void;
  onTyping?: (isTyping: boolean) => void;
  broadcastNewMessage?: (m: Message) => void;
}

const MAX_LEN = 2000;
const TYPING_THROTTLE_MS = 1500;
const TYPING_STOP_MS = 15000;
const ADMIN_MENTION_RE = /(^|\s)@admin(\s|$|[.,!?;:])/i;

interface UploadResult { uploadUrl: string; publicUrl: string; path: string }

async function getSignedUpload(contentType: string, bytes: number): Promise<UploadResult | null> {
  const res = await fetch('/api/messenger/upload-media', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ contentType, bytes }),
  });
  if (!res.ok) return null;
  return (await res.json()) as UploadResult;
}

async function putBlob(uploadUrl: string, blob: Blob, contentType: string): Promise<boolean> {
  try {
    const res = await fetch(uploadUrl, {
      method: 'PUT',
      headers: { 'content-type': contentType, 'x-upsert': 'true' },
      body: blob,
    });
    return res.ok;
  } catch {
    return false;
  }
}

function formatExpirySummary(seconds: number | null): string {
  if (seconds === null) return 'No Expiry';
  if (seconds < 3600) return `Expires In ${Math.round(seconds / 60)} Minutes`;
  if (seconds < 86_400) return `Expires In ${Math.round(seconds / 3600)} Hours`;
  return `Expires In ${Math.round(seconds / 86_400)} Days`;
}

export default function MessageComposer({ conversationId, selfId, replyTo, onClearReply, onTyping, broadcastNewMessage }: Props) {
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showAttach, setShowAttach] = useState(false);
  // round-19: state-driven mobile detection (matchMedia listener)
  // so the + button reliably opens the native photo/video picker on
  // mobile without re-checking on every click. Also gates the emoji
  // portal so it renders fixed-positioned on mobile.
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(max-width: 768px)');
    const sync = () => setIsMobile(mq.matches);
    sync();
    mq.addEventListener('change', sync);
    return () => mq.removeEventListener('change', sync);
  }, []);
  const [voiceMode, setVoiceMode] = useState(false);
  const [showGif, setShowGif] = useState(false);
  const [gifAvailable, setGifAvailable] = useState(true);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showScheduled, setShowScheduled] = useState(false);
  const [showExpiry, setShowExpiry] = useState(false);
  const [showScheduleInput, setShowScheduleInput] = useState(false);
  const [scheduleAt, setScheduleAt] = useState('');
  const [pendingExpirySeconds, setPendingExpirySeconds] = useState<number | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  // round-18: combined photo + video input for mobile. The + button on
  // mobile bypasses AttachMenu and clicks this input directly so the OS
  // opens its native photo/video library picker in one tap.
  const mobileMediaInputRef = useRef<HTMLInputElement>(null);
  const appendMessage = useMessengerStore((s) => s.appendMessage);
  const updateMessage = useMessengerStore((s) => s.updateMessage);
  const removeMessage = useMessengerStore((s) => s.removeMessage);

  const broadcastRef = useRef<((isTyping: boolean) => void) | null>(null);
  const lastSentAtRef = useRef(0);
  const stopTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const composerRef = useRef<HTMLDivElement>(null);

  const closeAllPopovers = useCallback(() => {
    setShowEmoji(false);
    setShowAttach(false);
    setShowGif(false);
    setShowTemplates(false);
    setShowScheduled(false);
    setShowExpiry(false);
    setShowScheduleInput(false);
  }, []);

  const togglePopover = useCallback((setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    vibrateLight();
    setter(prev => {
      if (!prev) closeAllPopovers();
      return !prev;
    });
  }, [closeAllPopovers]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      if (composerRef.current && !composerRef.current.contains(e.target as Node)) {
        closeAllPopovers();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [closeAllPopovers]);

  const adminMention = useMemo(() => ADMIN_MENTION_RE.test(text), [text]);

  // R28.1: detect if the user is composing into their support thread so we
  // can offer self-serve FAQ suggestions before they send. The support
  // thread is the only conversation where the counterparty is admin.
  const isSupportThread = useMessengerStore((s) => {
    const conv = s.conversations.find((c) => c.conversation_id === conversationId);
    return conv?.counterparty_role === 'admin';
  });

  const onTypingRef = useRef(onTyping);
  useEffect(() => {
    onTypingRef.current = onTyping;
  }, [onTyping]);

  useEffect(() => {
    return () => {
      if (stopTimerRef.current) clearTimeout(stopTimerRef.current);
      stopTimerRef.current = null;
      onTypingRef.current?.(false);
    };
  }, []);

  const stopTypingNow = useCallback(() => {
    if (stopTimerRef.current) clearTimeout(stopTimerRef.current);
    stopTimerRef.current = null;
    lastSentAtRef.current = 0;
    onTypingRef.current?.(false);
  }, []);

  useEffect(() => { if (voiceMode || showGif || showAttach) stopTypingNow(); }, [voiceMode, showGif, showAttach, stopTypingNow]);

  const pulseTyping = useCallback(() => {
    const now = Date.now();
    if (now - lastSentAtRef.current > TYPING_THROTTLE_MS) {
      onTypingRef.current?.(true);
      lastSentAtRef.current = now;
    }
    if (stopTimerRef.current) clearTimeout(stopTimerRef.current);
    stopTimerRef.current = setTimeout(() => {
      onTypingRef.current?.(false);
      lastSentAtRef.current = 0;
    }, TYPING_STOP_MS);
  }, []);


  const insertAtCursor = (chunk: string) => {
    const el = inputRef.current;
    if (!el) { setText((t) => t + chunk); return; }
    const start = el.selectionStart ?? text.length;
    const end = el.selectionEnd ?? text.length;
    const next = text.slice(0, start) + chunk + text.slice(end);
    setText(next.slice(0, MAX_LEN));
    queueMicrotask(() => {
      el.focus();
      const pos = start + chunk.length;
      el.setSelectionRange(pos, pos);
    });
  };

  const buildOptimistic = (overrides: Partial<Message> & { message_type: MessageType }, clientMessageId: string): Message => ({
    id: `temp-${clientMessageId}`,
    client_message_id: clientMessageId,
    conversation_id: conversationId,
    sender_id: selfId,
    text: null,
    media_url: null,
    media_metadata: {},
    reply_to_id: replyTo?.id ?? null,
    thread_parent_id: null,
    is_edited: false,
    is_deleted: false,
    delete_scope: null,
    priority: 'normal',
    status: 'sent',
    labels: [],
    expires_at: null,
    metadata: {},
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    ...overrides,
  });

  const sendOptimistic = async (
    optimistic: Message,
    payload: { text?: string; mediaUrl?: string; mediaMetadata?: Record<string, unknown>; messageType: MessageType; expiresAt?: string }
  ) => {
    appendMessage(conversationId, optimistic);
    setSending(true);
    // Audit10: stamp a fresh idempotency uuid per send. The server's
    // unique partial index on (conversation_id, sender_id, client_message_id)
    // + the 23505 replay path in send-message use this to dedup retries.
    const clientMessageId = optimistic.client_message_id!;
    try {
      playSendSound();
      vibrateMedium();

      const body: Record<string, unknown> = {
        conversationId,
        messageType: payload.messageType,
        replyToId: replyTo?.id,
        clientMessageId,
      };
      if (payload.text) body.text = payload.text;
      if (payload.mediaUrl) body.mediaUrl = payload.mediaUrl;
      if (payload.mediaMetadata) body.mediaMetadata = payload.mediaMetadata;
      if (payload.expiresAt) body.expiresAt = payload.expiresAt;
      const res = await fetch('/api/messenger/send-message', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const json = (await res.json().catch(() => ({}))) as { error?: string };
        updateMessage(conversationId, { ...optimistic, metadata: { ...optimistic.metadata, failed: true } });
        toast(json.error ?? 'Send Failed');
        return;
      }
      const json = (await res.json()) as { message: Message };
      removeMessage(conversationId, optimistic.id);
      appendMessage(conversationId, json.message);
      
      // Update sidebar snippet for sent message
      useMessengerStore.getState().updateConversationSnippet(json.message, false);

      setPendingExpirySeconds(null);
      if (broadcastNewMessage) broadcastNewMessage(json.message);
    } catch {
      updateMessage(conversationId, { ...optimistic, metadata: { ...optimistic.metadata, failed: true } });
      toast('Network Error');
    } finally {
      setSending(false);
    }
    onClearReply();
  };

  const handleSendText = useCallback(async () => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      toast('You Are Offline');
      return;
    }
    stopTypingNow();
    const expiresAt =
      pendingExpirySeconds === null
        ? undefined
        : new Date(Date.now() + pendingExpirySeconds * 1000).toISOString();
    const optimistic = buildOptimistic({
      message_type: 'text',
      text: trimmed,
      expires_at: expiresAt ?? null,
    }, crypto.randomUUID());
    setText('');
    await sendOptimistic(optimistic, { text: trimmed, messageType: 'text', expiresAt });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, sending, replyTo, conversationId, selfId, stopTypingNow, pendingExpirySeconds]);

  const handleSchedule = async () => {
    const trimmed = text.trim();
    if (!trimmed) { toast('Type A Message First'); return; }
    if (!scheduleAt) { toast('Pick A Send Time'); return; }
    const t = Date.parse(scheduleAt);
    if (Number.isNaN(t)) { toast('Invalid Time'); return; }
    if (t < Date.now() + 30_000) { toast('Pick A Time At Least Thirty Seconds Away'); return; }
    try {
      const res = await fetch('/api/messenger/schedule-message', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          action: 'create',
          conversationId,
          text: trimmed,
          messageType: 'text',
          scheduledAt: new Date(t).toISOString(),
          replyToId: replyTo?.id,
        }),
      });
      if (!res.ok) {
        const json = (await res.json().catch(() => ({}))) as { error?: string };
        toast(json.error ?? 'Could Not Schedule');
        return;
      }
      setText('');
      setScheduleAt('');
      setShowScheduleInput(false);
      onClearReply();
      toast('Message Scheduled');
    } catch {
      toast('Network Error');
    }
  };

  const uploadAndSend = async (blob: Blob, contentType: string, messageType: MessageType, metadata: Record<string, unknown>) => {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      toast('You Are Offline');
      return;
    }
    const localUrl = URL.createObjectURL(blob);
    const expiresAt =
      pendingExpirySeconds === null
        ? undefined
        : new Date(Date.now() + pendingExpirySeconds * 1000).toISOString();
    
    const optimistic = buildOptimistic({
      message_type: messageType,
      media_url: localUrl,
      media_metadata: metadata,
      expires_at: expiresAt ?? null,
    }, crypto.randomUUID());
    
    appendMessage(conversationId, optimistic);
    setSending(true);

    const sig = await getSignedUpload(contentType, blob.size);
    if (!sig) { 
      toast('Upload Sign Failed'); 
      updateMessage(conversationId, { ...optimistic, metadata: { ...optimistic.metadata, failed: true } });
      setSending(false); 
      return; 
    }
    const ok = await putBlob(sig.uploadUrl, blob, contentType);
    if (!ok) { 
      toast('Upload Failed'); 
      updateMessage(conversationId, { ...optimistic, metadata: { ...optimistic.metadata, failed: true } });
      setSending(false); 
      return; 
    }
    
    await sendOptimistic(optimistic, {
      mediaUrl: sig.publicUrl,
      mediaMetadata: metadata,
      messageType,
      expiresAt,
    });
    
    // Revoke blob URL after a short delay to ensure image has loaded
    setTimeout(() => URL.revokeObjectURL(localUrl), 5000);
  };

  const handleImage = async (file: File) => {
    const allowed = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
    if (!allowed.has(file.type)) { toast('Unsupported Image Type'); return; }
    await uploadAndSend(file, file.type, 'image', {
      filename: file.name, size: file.size, contentType: file.type,
    });
  };

  const handleVideo = async (file: File) => {
    const allowed = new Set([
      'video/mp4', 'video/webm', 'video/quicktime', 'video/x-m4v',
    ]);
    if (!allowed.has(file.type)) { toast('Unsupported Video Type. Use MP4, MOV, Or WebM'); return; }
    if (file.size > 200 * 1024 * 1024) { toast('Video Too Large (Max 200 MB)'); return; }
    await uploadAndSend(file, file.type, 'video', {
      filename: file.name, size: file.size, contentType: file.type,
      duration: null, // populated client-side if needed via VideoMetadata API
    });
  };

  const handleFile = async (file: File) => {
    const videoMimes = new Set(['video/mp4', 'video/webm', 'video/quicktime', 'video/x-m4v']);
    if (videoMimes.has(file.type)) { return handleVideo(file); }
    const allowed = new Set([
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'audio/webm', 'audio/mp4', 'audio/mpeg',
      'application/pdf',
    ]);
    if (!allowed.has(file.type)) { toast('Unsupported File Type'); return; }
    await uploadAndSend(file, file.type, 'file', {
      filename: file.name, size: file.size, contentType: file.type,
    });
  };

  const handleVoice = async (blob: Blob, durationSec: number) => {
    await uploadAndSend(blob, 'audio/webm', 'voice', { durationSec, size: blob.size });
    setVoiceMode(false);
  };

  const handleGif = async (gifUrl: string) => {
    setShowGif(false);
    const expiresAt =
      pendingExpirySeconds === null
        ? undefined
        : new Date(Date.now() + pendingExpirySeconds * 1000).toISOString();
    const optimistic = buildOptimistic({
      message_type: 'gif',
      media_url: gifUrl,
      expires_at: expiresAt ?? null,
    }, crypto.randomUUID());
    await sendOptimistic(optimistic, { mediaUrl: gifUrl, messageType: 'gif', expiresAt });
  };

  return (
    <div
      ref={composerRef}
      className="msg-composer"
      style={{
        borderTop: '4px solid var(--surface-3, #1D2D3E)',
        padding: 12,
        paddingBottom: 'max(12px, env(safe-area-inset-bottom))',
        background: 'var(--surface-1, #0F1923)',
        position: 'relative',
        flexShrink: 0,
      }}
    >
      <input ref={imageInputRef} type="file" accept="image/*" style={{ display: 'none' }}
        onChange={(e) => {
          const f = e.target.files?.[0];
          e.target.value = '';
          if (f) void handleImage(f);
        }}
      />
      <input ref={videoInputRef} type="file"
        accept="video/mp4,video/webm,video/quicktime,video/*"
        style={{ display: 'none' }}
        onChange={(e) => {
          const f = e.target.files?.[0];
          e.target.value = '';
          if (f) void handleVideo(f);
        }}
      />
      <input ref={fileInputRef} type="file" style={{ display: 'none' }}
        onChange={(e) => {
          const f = e.target.files?.[0];
          e.target.value = '';
          if (f) void handleFile(f);
        }}
      />
      {/* round-18: combined photo + video native picker for mobile.
          round-20: route by MIME so images call handleImage (renders as
          inline image bubble) and videos call handleVideo (renders with
          a player). Previously fell through to handleFile which sent
          everything as a generic file-attachment download link. */}
      <input ref={mobileMediaInputRef} type="file"
        accept="image/*,video/*"
        style={{ display: 'none' }}
        onChange={(e) => {
          const f = e.target.files?.[0];
          e.target.value = '';
          if (!f) return;
          if (f.type.startsWith('image/')) { void handleImage(f); return; }
          if (f.type.startsWith('video/')) { void handleVideo(f); return; }
          // Fallback: treat anything else as a generic file upload.
          void handleFile(f);
        }}
      />

      {replyTo && <ReplyChip replyTo={replyTo} onClear={onClearReply} />}

      {pendingExpirySeconds !== null && (
        <div
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 999,
            background: 'var(--surface-3, #1D2D3E)',
            color: 'var(--teal, #00C4BC)',
            fontSize: '0.72rem', fontWeight: 700,
            marginBottom: 6,
          }}
          role="status"
          aria-label="Pending Expiry"
        >
          <Clock size={10} aria-hidden="true" />
          {formatExpirySummary(pendingExpirySeconds)}
          <button
            type="button"
            onClick={() => setPendingExpirySeconds(null)}
            aria-label="Clear Expiry"
            style={{
              background: 'transparent', border: 0, color: 'var(--white, #FFFFFF)',
              cursor: 'pointer', padding: 0, marginLeft: 4, fontWeight: 700,
            }}
          >Clear</button>
        </div>
      )}

      <FaqSuggestions draft={text} enabled={isSupportThread && !voiceMode} />

      {voiceMode ? (
        <VoiceRecorder
          onComplete={(b, sec) => void handleVoice(b, sec)}
          onCancel={() => setVoiceMode(false)}
        />
      ) : (
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-end',
            gap: 12,
            padding: '8px 16px',
            background: 'var(--surface-1, #0F1923)',
            borderTop: '6px solid rgba(255, 255, 255, 0.06)',
          }}
        >
          {/* External Left Icon (Plus button) */}
          <div style={{ display: 'flex', alignItems: 'center', paddingBottom: 6 }}>
            <button
              type="button"
              onClick={() => {
                // round-19: state-driven mobile detection so the + button
                // ALWAYS dispatches the right action at click time.
                vibrateLight();
                if (isMobile) {
                  // Programmatic .click() on a hidden file input must
                  // be inside a user-gesture handler; this onClick IS
                  // the user gesture so iOS Safari accepts it and
                  // shows the system photo/video library picker.
                  mobileMediaInputRef.current?.click();
                } else {
                  togglePopover(setShowAttach);
                }
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                background: 'transparent',
                border: 'none',
                padding: 0,
                transition: 'transform 0.1s',
              }}
              className="hover-lift"
              aria-label="Add Media"
              title="Add Media"
            >
              <Image src="/messenger-icons/add-media-icon.png" alt="Add Media" width={200} height={200} unoptimized style={{ width: 48, height: 48, objectFit: 'contain', transform: 'scale(1.6)' }} />
            </button>
          </div>

          {/* iMessage Style Pill - Upgraded */}
          <div
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'flex-end',
              background: 'rgba(0,0,0,0.4)',
              borderRadius: 24,
              border: '4px solid rgba(255, 255, 255, 0.08)',
              padding: '6px',
              minHeight: 46,
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.6)',
              transition: 'border-color 0.2s',
            }}
            onFocus={(e) => { e.currentTarget.style.borderColor = 'rgba(0, 196, 188, 0.5)'; }}
            onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.08)'; }}
          >
            <textarea
              ref={inputRef}
              id="message-composer-input"
              name="message_composer_input"
              autoComplete="off"
              spellCheck="true"
              value={text}
              onChange={(e) => { setText(e.target.value.slice(0, MAX_LEN)); pulseTyping(); }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void handleSendText(); }
              }}
              onFocus={() => closeAllPopovers()}
              placeholder="Message"
              maxLength={MAX_LEN}
              rows={1}
              aria-label="Message Body"
              style={{
                flex: 1, resize: 'none', minHeight: 24, maxHeight: 120,
                padding: '5px 8px 0px 8px',
                background: 'transparent',
                border: 'none',
                color: 'var(--white, #FFFFFF)',
                fontFamily: 'inherit', fontSize: '1rem', outline: 'none',
                lineHeight: '24px',
                marginBottom: 5,
              }}
            />
            {/* Action buttons inside the right side of the pill */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, paddingBottom: 2 }}>
                  {/* round-15 fix: revert to ORIGINAL conditional render.
                      Send button only appears once the user starts typing
                      (text.trim() non-empty) or while sending. Cleaner UI
                      when the field is idle - matches the user's reference
                      desktop screenshot of how the composer should behave. */}
                  {text.trim() || sending ? (
                    <>
                  <button
                    type="button"
                    onClick={() => { vibrateMedium(); void handleSendText(); }}
                    disabled={!text.trim() || sending}
                    aria-label="Send Message" title="Send Message"
                    className="btn btn-primary"
                    style={{
                      borderRadius: '50%',
                      width: 32,
                      height: 32,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: 0,
                      margin: '0 2px 2px 0',
                      transition: 'transform 0.1s',
                      flexShrink: 0,
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="12" y1="19" x2="12" y2="5"></line>
                      <polyline points="5 12 12 5 19 12"></polyline>
                    </svg>
                  </button>
                </>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {adminMention && !voiceMode && (
        <div
          role="status"
          aria-label="Admin Will Be Notified"
          style={{
            marginTop: 6,
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            padding: '4px 10px',
            borderRadius: 999,
            background: 'var(--surface-3, #1D2D3E)',
            color: 'var(--teal, #00C4BC)',
            fontSize: '0.72rem',
            fontWeight: 700,
          }}
        >
          <Shield size={10} aria-hidden="true" />
          Admin Will Be Notified
        </div>
      )}

      {!voiceMode && (
        <div style={{ fontSize: '0.72rem', color: 'var(--grey-400, #A8B4C0)', textAlign: 'right', marginTop: 4 }}>
          {text.length} / {MAX_LEN}
        </div>
      )}

      {showAttach && (
        <AttachMenu
          onClose={() => setShowAttach(false)}
          onPickImage={() => imageInputRef.current?.click()}
          onPickVideo={() => videoInputRef.current?.click()}
          onPickVoice={() => setVoiceMode(true)}
          onPickFile={() => fileInputRef.current?.click()}
        />
      )}
      {showGif && (
        <GifPicker
          onPick={(u) => void handleGif(u)}
          onClose={() => setShowGif(false)}
          onUnavailable={() => setGifAvailable(false)}
        />
      )}
      {showTemplates && (
        <TemplatesMenu
          draftText={text}
          onPick={(body) => insertAtCursor(body)}
          onClose={() => setShowTemplates(false)}
        />
      )}
      {showExpiry && (
        <ExpiryPicker
          currentSeconds={pendingExpirySeconds}
          onPick={(s) => setPendingExpirySeconds(s)}
          onClose={() => setShowExpiry(false)}
        />
      )}
    </div>
  );
}

const iconBtn: React.CSSProperties = {
  background: 'transparent',
  border: 'none',
  borderRadius: '50%',
  width: 36,
  height: 36,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
  color: 'var(--grey-400, #A8B4C0)',
  transition: 'all 0.2s',
};
