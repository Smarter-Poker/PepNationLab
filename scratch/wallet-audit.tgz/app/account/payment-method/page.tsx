import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import PaymentMethodClient from './PaymentMethodClient';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Payment Methods | Pep Nation Lab',
  robots: { index: false, follow: true },
};

export default async function PaymentMethodPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?redirect=/account/payment-method');

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, default_payment_method, payment_handles')
    .eq('id', user.id)
    .maybeSingle();

  let mergedHandles = (profile?.payment_handles as Record<string, string> | null) ?? {};

  if (profile?.role && ['super_agent', 'agent', 'sub_agent'].includes(profile.role)) {
    const { data: agentProfile } = await supabase
      .from('agent_profiles')
      .select('payment_handles')
      .eq('id', user.id)
      .maybeSingle();
    
    if (agentProfile?.payment_handles) {
      mergedHandles = {
        ...(agentProfile.payment_handles as Record<string, string>),
        ...mergedHandles, // profile overrides agent
      };
    }
  }

  return (
    <div style={{ minHeight: '100dvh', background: 'var(--black)', padding: 'var(--space-6) var(--space-4)' }}>
      <div className="container" style={{ maxWidth: 720 }}>
        <h1 className="animated-gradient-text" style={{ color: 'var(--white)', fontSize: '1.6rem', fontFamily: 'var(--font-brand)', marginBottom: 'var(--space-2)' }}>
          Payment Methods
        </h1>
        <p style={{ color: 'var(--silver)', fontSize: '0.92rem', marginBottom: 'var(--space-5)' }}>
          These Are Your Preferred Payment Methods To Get Paid At Checkout.
        </p>
        <PaymentMethodClient
          initialDefault={profile?.default_payment_method ?? null}
          initialHandles={mergedHandles}
        />
      </div>
    </div>
  );
}
