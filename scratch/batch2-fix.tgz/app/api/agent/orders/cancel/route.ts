import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/server';
import { requireAgentOrAdmin } from '@/lib/admin-auth';
import { isAgentAncestorOf } from '@/lib/agent-auth';
import { assertSameOrigin } from '@/lib/csrf';
import { logOrderEvent } from '@/lib/order-events';
import { notifyOrderCancelled, notify } from '@/lib/notify';
import { emailConfigured, sendOrderCancelledEmail } from '@/lib/email';
import { shortOrderId } from '@/lib/push-enqueue';

const CancelSchema = z.object({
  orderId: z.string().uuid(),
  reason: z.string().min(1).max(500),
});

const NON_CANCELLABLE = new Set(['shipped', 'delivered', 'cancelled']);

export async function POST(req: NextRequest) {
  const csrf = assertSameOrigin(req);
  if (csrf) return csrf;

  const gate = await requireAgentOrAdmin();
  if (!gate.ok) return gate.response;

  const body = await req.json().catch(() => ({}));
  const parsed = CancelSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid Cancel Payload', details: parsed.error.issues }, { status: 400 });
  }

  const { orderId, reason } = parsed.data;
  const callerId = gate.user.id;
  const isAdmin = gate.isAdmin;

  const service = createAdminClient();

  // Fetch the order to verify permissions and check status.
  const { data: order, error: readErr } = await service
    .from('orders')
    .select('id, status, agent_id, buyer_id')
    .eq('id', orderId)
    .maybeSingle();

  if (readErr || !order) {
    return NextResponse.json({ error: 'Order Not Found.' }, { status: 404 });
  }

  // Non-admins must own the order (be the agent on record) OR be an upline
  // ancestor of that agent. Super agents see downline orders on their
  // dashboard; before this they could not cancel them (403).
  if (!isAdmin && order.agent_id !== callerId) {
    const isAncestor = order.agent_id
      ? await isAgentAncestorOf(service, callerId, order.agent_id)
      : false;
    if (!isAncestor) {
      return NextResponse.json({ error: 'You Are Not Authorized To Cancel This Order.' }, { status: 403 });
    }
  }

  if (NON_CANCELLABLE.has(order.status)) {
    return NextResponse.json(
      { error: `Cannot Cancel An Order That Is Already ${order.status}.` },
      { status: 422 }
    );
  }

  // Run the cancel RPC.
  const { error: rpcError } = await service.rpc('cancel_order', {
    p_order_id: orderId,
    p_reason: reason,
    p_refund_type: 'none',
    p_actor_id: callerId,
  });

  if (rpcError) {
    return NextResponse.json({ error: 'Failed to cancel order. Please try again.' }, { status: 422 });
  }

  // Fan-out: notifications + audit log. Best-effort — cancel is already committed.
  try {
    const short = shortOrderId(orderId);

    // Notify buyer
    if (order.buyer_id) {
      await notifyOrderCancelled(service, order.buyer_id, orderId, short);

      if (emailConfigured()) {
        const { data: buyerProf } = await service
          .from('profiles')
          .select('contact_email, email_verified, full_name')
          .eq('id', order.buyer_id)
          .maybeSingle();
        let to: string | null = (buyerProf?.contact_email && buyerProf.email_verified) ? buyerProf.contact_email : null;
        if (!to) {
          const { data: authUser } = await service.auth.admin.getUserById(order.buyer_id);
          to = authUser?.user?.email ?? null;
        }
        if (to) {
          sendOrderCancelledEmail({ to, fullName: buyerProf?.full_name ?? null, orderId }).catch(() => {});
        }
      }
    }

    // Notify agent if cancelled by an admin
    if (isAdmin && order.agent_id && order.agent_id !== callerId) {
      await notify(service, {
        userId: order.agent_id,
        type: 'system',
        title: `Order #${short} Cancelled By Admin`,
        body: `Order #${short} On Your Store Was Cancelled By An Administrator.${reason ? ` Reason: ${reason}` : ''}`,
        url: '/dashboard?tab=Orders',
      });
    }

    // Notify buyer if cancelled by agent (and buyer is different person)
    if (!isAdmin && order.buyer_id && order.buyer_id !== callerId) {
      await notify(service, {
        userId: order.buyer_id,
        type: 'system',
        title: `Order #${short} Cancelled`,
        body: `Your order has been cancelled by your agent.${reason ? ` Reason: ${reason}` : ''}`,
        url: `/orders/${orderId}`,
      });
    }

    await logOrderEvent(service, {
      orderId,
      event: 'cancelled',
      actorId: callerId,
      actorRole: isAdmin ? 'admin' : 'agent',
      payload: { reason, via: isAdmin ? 'admin_agent_cancel_endpoint' : 'agent_cancel_endpoint' },
    });
  } catch { /* fan-out must not mask committed cancel */ }

  return NextResponse.json({ success: true, cancelled: true });
}
