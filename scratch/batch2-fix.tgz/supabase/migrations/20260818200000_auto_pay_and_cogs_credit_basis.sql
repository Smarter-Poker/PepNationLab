-- =============================================================================
-- AUTO-PAY + CREDIT-BASIS ALIGNMENT (2026-08-18)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. auto_pay_invoice: the atomic engine behind the wallet's Auto-Pay toggle.
--    Service-role only (the daily cron calls it); re-validates everything
--    under row locks so the cron's pre-filter is never the safety.
--    Unlike pay_invoice (which records an OFF-platform payment), this one
--    actually debits the payer's prepaid balance - that is the whole point.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.auto_pay_invoice(p_target_type text, p_target_id uuid)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_payer uuid;
  v_payee uuid;
  v_owed numeric;
  v_status text;
  v_payer_row public.profiles%ROWTYPE;
  v_payer_after numeric;
  v_payee_before numeric;
  v_payee_after numeric;
BEGIN
  IF p_target_type = 'statement' THEN
    SELECT agent_id, total_owed, status INTO v_payer, v_owed, v_status
    FROM weekly_statements WHERE id = p_target_id FOR UPDATE;
    SELECT id INTO v_payee FROM profiles WHERE role = 'admin' ORDER BY created_at LIMIT 1;
  ELSIF p_target_type = 'agent_invoice' THEN
    SELECT agent_id, super_agent_id, total_owed, status
      INTO v_payer, v_payee, v_owed, v_status
    FROM agent_invoices WHERE id = p_target_id FOR UPDATE;
  ELSE
    RAISE EXCEPTION 'invalid_target_type';
  END IF;

  IF v_payer IS NULL THEN RETURN jsonb_build_object('ok', false, 'skipped', 'target_not_found'); END IF;
  IF v_status = 'paid' THEN RETURN jsonb_build_object('ok', false, 'skipped', 'already_paid'); END IF;
  IF v_owed IS NULL OR v_owed <= 0 THEN RETURN jsonb_build_object('ok', false, 'skipped', 'nothing_owed'); END IF;

  SELECT * INTO v_payer_row FROM profiles WHERE id = v_payer FOR UPDATE;
  IF v_payer_row.auto_pay_enabled IS DISTINCT FROM true THEN
    RETURN jsonb_build_object('ok', false, 'skipped', 'auto_pay_disabled');
  END IF;
  IF COALESCE(v_payer_row.prepaid_balance, 0) < v_owed THEN
    RETURN jsonb_build_object('ok', false, 'skipped', 'insufficient_balance');
  END IF;

  -- Debit the payer's prepaid balance.
  v_payer_after := round(COALESCE(v_payer_row.prepaid_balance, 0) - v_owed, 2);
  UPDATE profiles SET prepaid_balance = v_payer_after, updated_at = now() WHERE id = v_payer;
  INSERT INTO balance_transactions
    (agent_id, type, amount, balance_before, balance_after, description, reference_id, reference_type, created_by)
  VALUES
    (v_payer, 'statement_payment', v_owed,
     COALESCE(v_payer_row.prepaid_balance, 0), v_payer_after,
     format('Auto-Pay: %s Settled From Prepaid Balance', CASE WHEN p_target_type = 'statement' THEN 'Weekly Statement' ELSE 'Invoice' END),
     p_target_id,
     CASE WHEN p_target_type = 'statement' THEN 'statement' ELSE 'agent_invoice' END,
     NULL);

  -- Mark the bill paid.
  IF p_target_type = 'statement' THEN
    UPDATE weekly_statements
      SET status = 'paid', paid_at = now(), payment_method = 'auto_pay'
    WHERE id = p_target_id;
  ELSE
    UPDATE agent_invoices
      SET status = 'paid', paid_at = now(), payment_method = 'auto_pay', updated_at = now()
    WHERE id = p_target_id;
  END IF;

  -- Release the payer's credit line by the amount paid (credit accounts only),
  -- mirroring pay_invoice / admin_credit_account.
  IF v_payer_row.account_type = 'credit' THEN
    UPDATE profiles
      SET credit_used = GREATEST(0, round(COALESCE(credit_used, 0) - v_owed, 2)),
          updated_at = now()
    WHERE id = v_payer;
  END IF;

  -- Credit the payee's wallet.
  IF v_payee IS NOT NULL THEN
    SELECT COALESCE(prepaid_balance, 0) INTO v_payee_before FROM profiles WHERE id = v_payee FOR UPDATE;
    v_payee_after := round(v_payee_before + v_owed, 2);
    UPDATE profiles SET prepaid_balance = v_payee_after, updated_at = now() WHERE id = v_payee;
    INSERT INTO balance_transactions
      (agent_id, type, amount, balance_before, balance_after, description, reference_id, reference_type, created_by)
    VALUES
      (v_payee, 'invoice_payment_received', v_owed, v_payee_before, v_payee_after,
       format('Auto-Pay Received (%s)', p_target_type),
       p_target_id,
       CASE WHEN p_target_type = 'statement' THEN 'statement' ELSE 'agent_invoice' END,
       NULL);
  END IF;

  RETURN jsonb_build_object('ok', true, 'payer', v_payer, 'payee', v_payee, 'amount', v_owed);
END;
$function$;

-- Service-role only: this moves money with no caller identity.
REVOKE EXECUTE ON FUNCTION public.auto_pay_invoice(text, uuid) FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.auto_pay_invoice(text, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.auto_pay_invoice(text, uuid) FROM public;

-- -----------------------------------------------------------------------------
-- 2. charge_order_credit_line v2: charge the credit line on the SAME basis
--    the bills use. It previously charged orders.total (retail incl. shipping
--    and discounts) while weekly statements / invoices bill COGS - so even an
--    agent who paid every bill in full watched credit_used ratchet upward by
--    the retail margin of every order, forever. Now:
--      - regular sales charge the agent's own COGS: SUM(unit_cost_price * qty),
--        plus shipping only for DOWNLINE agents (super-agent invoices include
--        shipping; admin statements do not);
--      - wholesale restocks keep charging orders.total (their total IS the
--        wholesale cost - that checkout charge is the billing);
--      - a zero/unknown COGS falls back to orders.total (never under-charge).
--    Cancel stays symmetric automatically: reverse_order_credit_charge
--    reverses whatever amount the ledger row recorded.
--    The chain gate is unchanged.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.charge_order_credit_line(p_order_id uuid, p_created_by uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_order public.orders%ROWTYPE;
  v_profile public.profiles%ROWTYPE;
  v_agent public.profiles%ROWTYPE;
  v_super public.profiles%ROWTYPE;
  v_super_id uuid;
  v_unbilled numeric := 0;
  v_inflight numeric := 0;
  v_chain_projected numeric;
  v_charge numeric;
BEGIN
  -- Lock order to prevent concurrent duplicate charges
  SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Order % not found', p_order_id;
  END IF;

  -- Only applies if the order belongs to an agent
  IF v_order.agent_id IS NULL THEN
    RETURN;
  END IF;

  -- Verify it has not already been charged
  IF EXISTS (
    SELECT 1 FROM public.balance_transactions
    WHERE reference_id = p_order_id AND type = 'order_charge'
  ) THEN
    RETURN;
  END IF;

  -- ==== ATOMIC SUPER-AGENT CHAIN CREDIT GATE (H9 TOCTOU) ====
  -- Determine the billing super-agent for this order and, under its row lock,
  -- verify the chain's outstanding exposure. Mirrors checkSuperAgentCredit:
  -- pending_payment weekly statements + COGS of approved, non-restock, unbilled
  -- orders across the chain (super-agent + sub-agents), super-agent cost for
  -- sub-agent orders (fallback agent cost, clamped >= 0), plus shipping. THIS
  -- order is already committed-approved so it is naturally included in the sum.
  -- RAISE on breach: the caller demotes the order to agent_approval_pending.
  SELECT * INTO v_agent FROM public.profiles WHERE id = v_order.agent_id;
  IF v_agent.role = 'super_agent' OR v_agent.is_super_agent = true THEN
    v_super_id := v_agent.id;
  ELSIF v_agent.parent_agent_id IS NOT NULL THEN
    v_super_id := v_agent.parent_agent_id;
  ELSE
    v_super_id := NULL;
  END IF;

  IF v_super_id IS NOT NULL THEN
    SELECT * INTO v_super FROM public.profiles WHERE id = v_super_id FOR UPDATE;
    IF FOUND AND v_super.account_type = 'credit' THEN
      SELECT COALESCE(SUM(total_owed), 0) INTO v_unbilled
      FROM public.weekly_statements
      WHERE agent_id = v_super_id AND status = 'pending_payment';

      SELECT COALESCE(SUM(order_cost), 0) INTO v_inflight
      FROM (
        SELECT COALESCE(o.shipping_cost, 0) + COALESCE((
          SELECT SUM(
            GREATEST(0,
              CASE
                WHEN o.agent_id <> v_super_id THEN
                  CASE WHEN oi.unit_super_agent_cost IS NOT NULL AND oi.unit_super_agent_cost > 0
                       THEN oi.unit_super_agent_cost ELSE COALESCE(oi.unit_cost_price, 0) END
                ELSE COALESCE(oi.unit_cost_price, 0)
              END
            ) * COALESCE(oi.quantity, 0)
          )
          FROM public.order_items oi WHERE oi.order_id = o.id
        ), 0) AS order_cost
        FROM public.orders o
        WHERE o.agent_id IN (
            SELECT id FROM public.profiles
            WHERE id = v_super_id OR parent_agent_id = v_super_id
          )
          AND COALESCE(o.is_wholesale_restock, false) = false
          AND o.status IN ('approved_ship', 'approved_pickup', 'in_fulfillment', 'shipped', 'delivered')
          AND NOT EXISTS (SELECT 1 FROM public.statement_orders so WHERE so.order_id = o.id)
      ) chain_orders;

      v_chain_projected := v_unbilled + v_inflight;
      IF v_chain_projected > COALESCE(v_super.credit_limit, 0) THEN
        RAISE EXCEPTION 'Chain credit limit exceeded. Projected %, limit %',
          round(v_chain_projected, 2), COALESCE(v_super.credit_limit, 0)
          USING ERRCODE = 'check_violation';
      END IF;
    END IF;
  END IF;
  -- ==== end chain gate ====

  SELECT * INTO v_profile FROM public.profiles WHERE id = v_order.agent_id FOR UPDATE;

  -- Only charge credit line for 'credit' account types
  IF v_profile.account_type IS DISTINCT FROM 'credit' THEN
    RETURN;
  END IF;

  -- Billable amount (see header comment).
  IF COALESCE(v_order.is_wholesale_restock, false) THEN
    v_charge := v_order.total;
  ELSE
    SELECT COALESCE(SUM(GREATEST(0, COALESCE(oi.unit_cost_price, 0)) * COALESCE(oi.quantity, 0)), 0)
      INTO v_charge
    FROM public.order_items oi WHERE oi.order_id = p_order_id;
    IF v_profile.parent_agent_id IS NOT NULL THEN
      v_charge := v_charge + COALESCE(v_order.shipping_cost, 0);
    END IF;
    IF v_charge <= 0 THEN
      v_charge := v_order.total;
    END IF;
  END IF;
  v_charge := round(v_charge, 2);

  IF COALESCE(v_profile.credit_used, 0) + v_charge > COALESCE(v_profile.credit_limit, 0) THEN
    RAISE EXCEPTION 'Insufficient credit line limit. Required: %, Available: %',
      v_charge,
      COALESCE(v_profile.credit_limit, 0) - COALESCE(v_profile.credit_used, 0);
  END IF;

  UPDATE public.profiles
  SET credit_used = COALESCE(credit_used, 0) + v_charge,
      updated_at = NOW()
  WHERE id = v_order.agent_id;

  INSERT INTO public.balance_transactions
    (agent_id, type, amount, description, reference_id, reference_type, created_by)
  VALUES
    (v_order.agent_id, 'order_charge', v_charge,
     'Credit Charge For Order ' || left(p_order_id::text, 8),
     p_order_id, 'order', p_created_by);

END;
$function$;
