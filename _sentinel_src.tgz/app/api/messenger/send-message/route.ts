import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseUrl } from '@/lib/supabase/url';
import { createAdminClient } from '@/lib/supabase/server';
import { assertSameOrigin } from '@/lib/csrf';
import { requireSession, getParticipant } from '@/lib/messenger/server';
import { messengerRateLimit, messengerRateLimitResponse } from '@/lib/messengerRateLimit';
import { SendMessageSchema } from '@/lib/messenger/schemas';
import { sanitizeMessageText } from '@/lib/messenger/sanitize';
import { hasAdminMention, recordAdminMention } from '@/lib/messenger/admin-mentions';
import { enqueuePush } from '@/lib/push-enqueue';
import { notifyNewMessage, notifySupportMessage } from '@/lib/notify';
import { sendBroadcast } from '@/lib/messenger/broadcast';
import { signMessengerMediaUrl } from '@/lib/messenger/signMedia';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const csrf = assertSameOrigin(req);
  if (csrf) return csrf;

  const { user, error } = await requireSession();
  if (error) return NextResponse.json({ error }, { status: 401 });

  const limited = await messengerRateLimit('send', user.id);
  if (!limited.allowed) return messengerRateLimitResponse(limited);

  const body = await req.json().catch(() => ({}));
  const parsed = SendMessageSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid Body', details: parsed.error.flatten() }, { status: 400 });
  }

  // Audit9: participant check moved BEFORE content validation so non-members
  // can't probe text/expiresAt validation surface.
  const participant = await getParticipant(parsed.data.conversationId, user.id);
  if (!participant) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  let cleanText: string | null = null;
  if (parsed.data.text !== undefined) {
    cleanText = sanitizeMessageText(parsed.data.text);
    if (cleanText === null) {
      return NextResponse.json({ error: 'Unsafe Text' }, { status: 400 });
    }
    // BUG 3 fix: re-check length AFTER sanitization because HTML entity escaping
    // (e.g., '<' -> '&lt;') can expand the raw 2,000-char input significantly.
    if (cleanText.length > 4_000) {
      return NextResponse.json({ error: 'Message Too Long After Sanitization' }, { status: 400 });
    }
    if (cleanText.length === 0 && !parsed.data.mediaUrl) {
      return NextResponse.json({ error: 'Empty Message' }, { status: 400 });
    }
  }

  // Security: Validate mediaUrl is from a trusted domain (our Supabase storage or Tenor CDN).
  // This prevents attacker-injected external URLs from being persisted and displayed to recipients.
  if (parsed.data.mediaUrl) {
    try {
      const mediaUrlObj = new URL(parsed.data.mediaUrl);
      const hostname = mediaUrlObj.hostname.toLowerCase();
      const supabaseHost = new URL(getSupabaseUrl()).hostname.toLowerCase();
      const allowedHosts = [
        supabaseHost,
        'c.tenor.com', // Tenor GIF CDN
        'media.tenor.com', // Tenor GIF CDN (alternate)
      ];
      if (!allowedHosts.some((h) => hostname === h || hostname.endsWith(`.${h}`))) {
        return NextResponse.json({ error: 'Media URL Domain Not Allowed' }, { status: 400 });
      }
    } catch {
      return NextResponse.json({ error: 'Invalid Media URL' }, { status: 400 });
    }
  }

  let expiresAt: string | null = null;
  if (parsed.data.expiresAt) {
    const t = Date.parse(parsed.data.expiresAt);
    if (Number.isNaN(t)) {
      return NextResponse.json({ error: 'Invalid expiresAt' }, { status: 400 });
    }
    const minMs = Date.now() + 60_000;
    const maxMs = Date.now() + 60 * 60 * 24 * 30 * 1000;
    if (t < minMs) {
      return NextResponse.json({ error: 'expiresAt Must Be At Least One Minute In The Future' }, { status: 400 });
    }
    if (t > maxMs) {
      return NextResponse.json({ error: 'expiresAt Cannot Exceed Thirty Days' }, { status: 400 });
    }
    expiresAt = new Date(t).toISOString();
  }

  const svc = createAdminClient();

  // Audit9: idempotent replay - same client_message_id from the same
  // (conversation_id, sender_id) returns the existing row instead of creating
  // a duplicate. The DB unique index enforces this even on race.
  if (parsed.data.clientMessageId) {
    const { data: existing } = await svc
      .from('messenger_messages')
      .select('*')
      .eq('conversation_id', parsed.data.conversationId)
      .eq('sender_id', user.id)
      .eq('client_message_id', parsed.data.clientMessageId)
      .maybeSingle();
    if (existing) {
      const signed = { ...existing, media_url: await signMessengerMediaUrl((existing as { media_url?: string | null }).media_url) };
      return NextResponse.json({ message: signed, idempotent: true });
    }
  }

  if (parsed.data.replyToId) {
    const { data: parent } = await svc
      .from('messenger_messages')
      .select('conversation_id, is_deleted')
      .eq('id', parsed.data.replyToId)
      .maybeSingle();
    if (!parent || parent.conversation_id !== parsed.data.conversationId) {
      return NextResponse.json({ error: 'Invalid Reply Target' }, { status: 400 });
    }
    if (parent.is_deleted) {
      return NextResponse.json({ error: 'Reply Target Deleted' }, { status: 410 });
    }
  }
  if (parsed.data.threadParentId) {
    const { data: thread } = await svc
      .from('messenger_messages')
      .select('conversation_id, is_deleted')
      .eq('id', parsed.data.threadParentId)
      .maybeSingle();
    if (!thread || thread.conversation_id !== parsed.data.conversationId) {
      return NextResponse.json({ error: 'Invalid Thread Parent' }, { status: 400 });
    }
    if (thread.is_deleted) {
      return NextResponse.json({ error: 'Thread Parent Deleted' }, { status: 410 });
    }
  }

  const insertRow: Record<string, unknown> = {
    conversation_id: parsed.data.conversationId,
    sender_id: user.id,
    text: cleanText,
    message_type: parsed.data.messageType,
    media_url: parsed.data.mediaUrl ?? null,
    media_metadata: parsed.data.mediaMetadata ?? {},
    reply_to_id: parsed.data.replyToId ?? null,
    thread_parent_id: parsed.data.threadParentId ?? null,
  };
  if (expiresAt) insertRow.expires_at = expiresAt;
  if (parsed.data.clientMessageId) insertRow.client_message_id = parsed.data.clientMessageId;

  const { data: inserted, error: insErr } = await svc
    .from('messenger_messages')
    .insert(insertRow)
    .select('*')
    .maybeSingle();

  if (insErr) {
    const code = (insErr as { code?: string }).code;
    // Audit9: idempotency race - return the existing row on unique violation.
    if (code === '23505' && parsed.data.clientMessageId) {
      const { data: existing } = await svc
        .from('messenger_messages')
        .select('*')
        .eq('conversation_id', parsed.data.conversationId)
        .eq('sender_id', user.id)
        .eq('client_message_id', parsed.data.clientMessageId)
        .maybeSingle();
      if (existing) {
        const signed = { ...existing, media_url: await signMessengerMediaUrl((existing as { media_url?: string | null }).media_url) };
        return NextResponse.json({ message: signed, idempotent: true });
      }
    }
    return NextResponse.json({ error: 'An Unexpected Error Occurred' }, { status: 500 });
  }
  if (!inserted) {
    return NextResponse.json({ error: 'Insert Failed' }, { status: 500 });
  }

  // Re-sign private-bucket media once; the signed object feeds both the
  // realtime broadcasts and the JSON response (optimistic UI).
  const outgoing = {
    ...inserted,
    media_url: await signMessengerMediaUrl((inserted as { media_url?: string | null }).media_url),
  };

  if (cleanText && hasAdminMention(cleanText)) {
    await recordAdminMention(svc, {
      messageId: (inserted as { id: string }).id,
      conversationId: parsed.data.conversationId,
      senderId: user.id,
      text: cleanText,
    });
  }

  // Awaited in-app notification + push to all OTHER conversation participants.
  // Never blocks the response - notification side-effects must not slow sends.
  try {
    // Get sender display name + role (role drives the support-notification branch)
    const { data: senderProfile } = await svc
      .from('profiles')
      .select('full_name, role')
      .eq('id', user.id)
      .maybeSingle();
    const senderName = senderProfile?.full_name || 'Someone';
    const senderRole = (senderProfile as { role?: string } | null)?.role ?? null;

    // Get all OTHER participants in this conversation (fetched after insert so unread_count is updated by trigger)
    const { data: participants } = await svc
      .from('messenger_participants')
      .select('*')
      .eq('conversation_id', parsed.data.conversationId)
      .neq('user_id', user.id);

    // Customer Support v2: if this is a support thread AND the sender is not
    // admin, fire a dedicated support_message notification to the admin
    // participant(s) so the bell + push announce a researcher reply. The
    // standard new_message notification continues firing alongside this -
    // the support_message helper gives admins a distinct, jump-to-thread bell
    // entry titled "Support - <name>" so the support inbox is the canonical
    // surface and is not buried under generic chat noise.
    let isSupport = false;
    if (senderRole !== 'admin') {
      const { data: conv } = await svc
        .from('messenger_conversations')
        .select('is_support')
        .eq('id', parsed.data.conversationId)
        .maybeSingle();
      isSupport = Boolean((conv as { is_support?: boolean } | null)?.is_support);

      if (isSupport) {
        const { count } = await svc
          .from('messenger_messages')
          .select('id', { count: 'exact', head: true })
          .eq('conversation_id', parsed.data.conversationId)
          .eq('sender_id', user.id);

        if (count === 1 && participants && participants.length > 0) {
          // BUG 1 fix: only send auto-ACK if an admin participant is explicitly in the
          // thread. The previous `|| participants[0]` fallback would impersonate the
          // first non-admin participant (typically the agent) as the bot sender.
          const adminParticipant = participants.find((p: any) => p.role === 'admin');
          if (adminParticipant) {
            const autoAckText = "Thanks for reaching out to Help & Support. Someone from our customer service team will respond shortly. Average reply time is under an hour. If this is urgent, please include your order number or any other helpful information in your next message";
            const { data: autoAckMsg } = await svc.from('messenger_messages').insert({
              conversation_id: parsed.data.conversationId,
              sender_id: adminParticipant.user_id,
              text: autoAckText,
              message_type: 'text',
              metadata: { auto_ack: true }
            }).select('*').maybeSingle();

            if (autoAckMsg) {
              sendBroadcast({
                topic: `conversation:${parsed.data.conversationId}`,
                event: 'new_message',
                payload: { message: autoAckMsg },
              }).catch(() => {});
            }
          }
        }
      }
    }

    if (participants && participants.length > 0) {
      // Build notification body - truncate long messages
      const isMedia = !cleanText && parsed.data.mediaUrl;
      const rawBody = cleanText ?? (isMedia ? 'Media Attachment' : 'New Message');
      const body = rawBody.length > 120 ? `${rawBody.slice(0, 117)}...` : rawBody;
      const url = `/messenger?conv=${parsed.data.conversationId}`;
      const tag = `msg-${parsed.data.conversationId}`;

      // Enqueue in-app notification + push for each recipient
      await Promise.allSettled(
        participants.map(async (p: any) => {
          try {
            // In-app notification (shows in bell immediately via Realtime)
            await notifyNewMessage(svc, p.user_id, senderName, rawBody, parsed.data.conversationId);

            // Customer Support v2: extra dedicated support_message bell entry
            // for admin recipients on is_support threads. Wrapped tightly so a
            // failure here never blocks the rest of the notification fanout.
            if (isSupport) {
              try {
                const { data: recipientProfile } = await svc
                  .from('profiles')
                  .select('role')
                  .eq('id', p.user_id)
                  .maybeSingle();
                const recipientRole = (recipientProfile as { role?: string } | null)?.role ?? null;
                if (recipientRole === 'admin') {
                  await notifySupportMessage(svc, p.user_id, senderName, rawBody, parsed.data.conversationId);
                }
              } catch {
                // notification is best-effort
              }
            }

            // Web push (background, requires subscription + permission)
            await enqueuePush(svc, {
              userId: p.user_id,
              title: senderName,
              body,
              url,
              event: 'message',
              tag,
            });
            // Broadcast to the user's personal channel (for OS notifications)
            await sendBroadcast({
              topic: `user_notify:${p.user_id}`,
              event: 'new_message_notify',
              payload: { message: outgoing },
            });
            // Broadcast to the user's unread channel (for the red badge)
            await sendBroadcast({
              topic: `user_unread:${p.user_id}`,
              event: 'participant_updated',
              payload: { participant: p },
            });
          } catch (err) {
            console.error(`[send-message] failed to notify participant ${p.user_id}:`, err);
          }
        })
      );
    }
  } catch {
    // Never propagate - notifications are best-effort
  }

  // Broadcast to the sender's notify channel so their OTHER devices update the sidebar
  await sendBroadcast({
    topic: `user_notify:${user.id}`,
    event: 'new_message_notify',
    payload: { message: outgoing },
  });

  // Broadcast the message payload to the conversation channel
  await sendBroadcast({
    topic: `conversation:${parsed.data.conversationId}`,
    event: 'new_message',
    payload: { message: outgoing },
  });

  return NextResponse.json({ message: outgoing });
}
