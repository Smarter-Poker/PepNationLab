/**
 * Browse compounds bucketed by molecular weight (Da). Server component.
 */

import type { Metadata } from 'next';
import Link from 'next/link';
import { getAllCompounds } from '@/lib/compounds-server';
import { evidenceTier } from '@/lib/compounds';
import BrowseFilterShell from '@/components/research/BrowseFilterShell';

export const metadata: Metadata = {
  title: 'Browse Peptides By Molecular Weight | Research Library | Pep Nation Lab',
  description: 'Browse research peptides sorted by molecular weight (Daltons). Understand bioavailability and delivery implications of molecular weight differences. Research use only.',
  robots: { index: true, follow: true },
  alternates: { canonical: 'https://pepnationlab.com/research/by-mw' },
  openGraph: {
    title: 'Peptides By Molecular Weight | Pep Nation Lab',
    description: 'Browse research peptides sorted by molecular weight with bioavailability context.',
    url: 'https://pepnationlab.com/research/by-mw',
    type: 'website',
    images: [{ url: '/og-card.png', width: 1200, height: 630, alt: 'Peptides By Molecular Weight' }],
  },
  twitter: {
    card: 'summary_large_image',
    site: '@PepNationLab',
    creator: '@PepNationLab',
    title: 'Browse Peptides By Molecular Weight | Research Library | Pep Nation Lab',
    description: 'Browse research peptides sorted by molecular weight (Daltons). Understand bioavailability and delivery implications of molecular weight differences. Research use only.',
    images: ['https://pepnationlab.com/og-card.png'],
  },
};

// ISR: data comes from unstable_cache'd helpers (60s); render once, revalidate hourly.
export const revalidate = 3600;

interface MwRow {
  slug: string;
  display_name: string;
  evidence_tier: string;
  plain_summary: string | null;
  molecular_weight_da: number | null;
}

const BUCKETS = [
  { key: 'small', label: 'Small (< 2,000 Da)', test: (mw: number) => mw < 2000 },
  { key: 'medium', label: 'Medium (2,000-5,000 Da)', test: (mw: number) => mw >= 2000 && mw < 5000 },
  { key: 'large', label: 'Large (> 5,000 Da)', test: (mw: number) => mw >= 5000 },
];

function CompoundCard({ c }: { c: MwRow }) {
  const t = evidenceTier(c.evidence_tier);
  return (
    <Link
      href={`/research/${c.slug}`}
      className="glass-panel"
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-1, 4px)',
        padding: 'var(--space-3, 12px) var(--space-4, 16px)',
        borderRadius: 'var(--radius-lg, 12px)',
        textDecoration: 'none',
        color: 'var(--white, #FFFFFF)',
      }}
    >
      <span style={{ fontSize: '0.7rem', color: t.color, textTransform: 'uppercase', letterSpacing: '0.04em', fontWeight: 700 }}>
        {t.label}
      </span>
      <span style={{ fontSize: '1rem', fontWeight: 700 }}>{c.display_name}</span>
      <span style={{ fontSize: '0.78rem', color: 'var(--teal, #00C4BC)' }}>
        MW: {c.molecular_weight_da?.toFixed(1)} Da
      </span>
    </Link>
  );
}

export default async function ResearchByMwPage() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'CollectionPage',
        '@id': 'https://pepnationlab.com/research/by-mw#webpage',
        url: 'https://pepnationlab.com/research/by-mw',
        name: 'Browse Peptides By Molecular Weight | Research Library | Pep Nation Lab',
        description: 'Browse research peptides sorted by molecular weight (Daltons). Understand bioavailability and delivery implications of molecular weight differences. Research use only.',
        isPartOf: { '@id': 'https://pepnationlab.com/#website' },
        publisher: { '@id': 'https://pepnationlab.com/#organization' }
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://pepnationlab.com' },
          { '@type': 'ListItem', position: 2, name: 'Research Library', item: 'https://pepnationlab.com/research' },
          { '@type': 'ListItem', position: 3, name: 'by mw', item: 'https://pepnationlab.com/research/by-mw' }
        ]
      }
    ]
  };

  const rows = (await getAllCompounds()) as unknown as MwRow[];

  const groups = BUCKETS.map((b) => ({ ...b, compounds: [] as MwRow[] }));
  const unknown: MwRow[] = [];
  for (const r of rows) {
    const mw = r.molecular_weight_da;
    if (mw === null || mw === undefined || !isFinite(mw)) {
      unknown.push(r);
      continue;
    }
    const target = groups.find((g) => g.test(mw));
    if (target) target.compounds.push(r);
  }

  const shellGroups = [
    ...groups.map((g) => ({
      key: g.key,
      label: g.label,
      count: g.compounds.length,
      children: (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 'var(--space-3, 12px)' }}>
          {g.compounds.map((c) => <CompoundCard key={c.slug} c={c} />)}
        </div>
      ),
    })),
    ...(unknown.length > 0
      ? [
          {
            key: 'unknown',
            label: 'Awaiting Data',
            count: unknown.length,
            children: (
              <div>
                <p style={{ fontSize: '0.85rem', color: 'var(--silver, #A8B4C0)', marginBottom: 'var(--space-3, 12px)' }}>
                  Molecular Weight Not Yet Available For These Compounds.
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--space-2, 8px)' }}>
                  {unknown.map((c) => (
                    <Link
                      key={c.slug}
                      href={`/research/${c.slug}`}
                      className="glass-panel"
                      style={{ padding: '6px 12px', borderRadius: 'var(--radius-md, 8px)', textDecoration: 'none', color: 'var(--white, #FFFFFF)', fontSize: '0.85rem' }}
                    >
                      {c.display_name}
                    </Link>
                  ))}
                </div>
              </div>
            ),
          },
        ]
      : []),
  ];

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: 'var(--space-6, 32px) var(--space-4, 16px)' }}>
      <nav style={{ marginBottom: 'var(--space-4, 16px)' }}>
        <Link href="/research" style={{ color: 'var(--teal, #00C4BC)', fontSize: '0.9rem', textDecoration: 'none' }}>
          Back To Research Library
        </Link>
      </nav>
      <header style={{ marginBottom: 'var(--space-5, 24px)' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--white, #FFFFFF)', margin: 0 }}>
          Browse By Molecular Weight
        </h1>
        <p style={{ color: 'var(--silver, #A8B4C0)', fontSize: '1.05rem', marginTop: 'var(--space-2, 8px)', maxWidth: '760px' }}>
          Compounds Grouped By Molecular Weight In Daltons. Select A Size Category Below.
        </p>
      </header>

      <BrowseFilterShell groups={shellGroups} emptyMessage="No Compounds In This Weight Range Yet." />
    </div>
      </>
  );
}
