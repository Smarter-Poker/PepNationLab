import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase/server';
import { requireAgentOrAdmin } from '@/lib/admin-auth';
import { assertSameOrigin } from '@/lib/csrf';
import { computeAgentCostForAgent, computeAgentCostsForAgent } from '@/lib/pricing';
import type { AgentTier } from '@/lib/pricing';
import { AgentProductPatchSchema } from '@/lib/schemas/product';
import { parseJsonBody } from '@/lib/schemas/http';

// requireAgentOrAdmin is ownership-safe here: every query below is scoped to
// agent_id = caller id, so an admin passing through only ever touches the
// house store's own rows. The admin's cost basis is base_cost (COGS), not a
// tier-multiplied agent cost.
//
// MANUFACTURER STORES (2026-07-15): a profile with is_manufacturer = true has
// UNRESTRICTED pricing -- no MAP floor, no cost floor, no admin-price ceiling,
// no margin cap. Their cost basis is their own private
// agent_products.manufacturer_cost (per 10-pack), which they may edit here.

export async function GET(req: NextRequest) {
  const gate = await requireAgentOrAdmin();
  if (!gate.ok) return gate.response;

  try {
    const supabase = await createServiceClient();
    const agentId = gate.user.id;

    const { data: profile } = await supabase
      .from('profiles')
      .select('tier, is_manufacturer')
      .eq('id', agentId)
      .maybeSingle();

    const tier = ((profile?.tier as AgentTier | null) ?? 'tier_3') as AgentTier;
    const isManufacturer = Boolean((profile as { is_manufacturer?: boolean | null } | null)?.is_manufacturer);

    const { data, error } = await supabase
      .from('agent_products')
      .select(`
        id, agent_id, product_id, custom_name, custom_description,
        custom_image_url, retail_price, margin_percent, is_visible, is_on_sale, sale_price, sort_order,
        manufacturer_cost,
        products (name, description, image_url, category, compound_slug, in_stock, inventory_count,
                 unit_size, unit_measure, base_cost, house_cost,
                 max_retail_price,
                 market_avg_price, market_low_price, market_high_price)
      `)
      .eq('agent_id', agentId)
      .order('sort_order', { ascending: true });

    if (error) {
      return NextResponse.json({ error: 'An Unexpected Error Occurred.' }, { status: 500 });
    }

    const rows = data ?? [];

    // Resolve the agent's pricing context once and price the whole catalog in
    // memory - previously this issued 2-3 queries per agent product.
    // Manufacturers have no tier-derived cost: their cost basis is their own
    // manufacturer_cost column, surfaced per row below.
    const pricedProducts = rows
      .filter(ap => ap.product_id && (ap.products as any)?.base_cost != null && Number((ap.products as any).base_cost) > 0)
      .map(ap => ({ id: ap.product_id as string, base_cost: Number((ap.products as any).base_cost) }));
    const costMap = (gate.isAdmin || isManufacturer)
      ? new Map<string, number>()
      : await computeAgentCostsForAgent(supabase, agentId, tier, pricedProducts);

    const augmented = rows.map(ap => {
      const productId = ap.product_id as string;
      const baseCost = (ap.products as any)?.base_cost != null
        ? Number((ap.products as any).base_cost)
        : 0;
      const houseCost = (ap.products as any)?.house_cost != null ? Number((ap.products as any).house_cost) : baseCost;

      // Admin cost basis is base_cost (true COGS on the house store); agents
      // get their tier-multiplied / custom-scaled cost; manufacturers get
      // their own entered production cost (may be null until they set it).
      let agentCost: number | null = 0;
      if (isManufacturer) {
        agentCost = (ap as { manufacturer_cost?: number | null }).manufacturer_cost != null
          ? Number((ap as { manufacturer_cost?: number | null }).manufacturer_cost)
          : null;
      } else if (baseCost > 0) {
        agentCost = gate.isAdmin ? houseCost : (costMap.get(productId) ?? 0);
      }

      const { base_cost: _stripped, house_cost: _strippedHouse, ...safeProducts } = (ap.products as any) ?? {};
      void _stripped; void _strippedHouse;

      return {
        ...ap,
        products: safeProducts,
        agent_cost: isManufacturer ? agentCost : (baseCost > 0 ? agentCost : null),
        agent_tier: tier,
        is_manufacturer: isManufacturer,
        max_retail_price: (ap.products as any)?.max_retail_price ?? null,
      };
    });

    return NextResponse.json({ data: augmented });
  } catch (err) {
    console.error('[agent/products] GET error:', err);
    return NextResponse.json({ error: 'An Unexpected Error Occurred.' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const csrf = assertSameOrigin(req);
  if (csrf) return csrf;

  const gate = await requireAgentOrAdmin();
  if (!gate.ok) return gate.response;

  // Schema-locked body: money fields (retail_price, sale_price,
  // margin_percent, manufacturer_cost) are rejected at the boundary if they
  // are NaN, Infinity, strings, or negative. Previously a NaN sale_price
  // sailed through the MAP/cost-floor guards below (NaN comparisons are
  // always false) and was written raw to agent_products.sale_price -- a
  // column checkout pricing reads directly.
  const parsed = await parseJsonBody(req, AgentProductPatchSchema);
  if (!parsed.ok) return parsed.response;
  const {
    id,
    custom_name,
    custom_description,
    custom_image_url,
    retail_price,
    margin_percent,
    is_visible,
    is_on_sale,
    sale_price,
    manufacturer_cost,
  } = parsed.data;

  try {
    const supabase = await createServiceClient();

    const { data: check } = await supabase
      .from('agent_products')
      .select(`
        id, retail_price, margin_percent, product_id, agent_id, sale_price, is_on_sale,
        products ( min_retail_price, max_margin_percent, max_retail_price, base_cost, house_cost )
      `)
      .eq('id', id)
      .eq('agent_id', gate.user.id)
      .maybeSingle();

    if (!check) {
      return NextResponse.json({ error: 'Unauthorized Or Not Found' }, { status: 403 });
    }

    // Cost floor: base_cost (COGS) for the admin house store, tier-derived
    // cost for agents. All price/margin guardrails below key off this value.
    let agentCostPer10 = 0;
    // Per-agent exemption from the retail margin ceiling (top sellers, e.g. Savage Brands).
    let marginCapExempt = false;
    // Manufacturer stores: zero pricing restrictions of any kind.
    let isManufacturer = false;
    if (gate.isAdmin) {
      const rawBase = (check.products as any)?.house_cost ?? (check.products as any)?.base_cost;
      agentCostPer10 = rawBase != null ? Number(rawBase) : 0;
    } else {
      const { data: profData } = await supabase
        .from('profiles')
        .select('tier, margin_cap_exempt, is_manufacturer')
        .eq('id', gate.user.id)
        .maybeSingle();
      isManufacturer = Boolean((profData as { is_manufacturer?: boolean | null } | null)?.is_manufacturer);
      marginCapExempt = Boolean((profData as { margin_cap_exempt?: boolean } | null)?.margin_cap_exempt);
      if (!isManufacturer && profData?.tier) {
        agentCostPer10 = await computeAgentCostForAgent(supabase, check.product_id, gate.user.id, profData.tier as AgentTier);
      }
    }

    let resolvedRetailPrice: number | undefined;
    let resolvedMarginPercent: number | undefined;

    if (retail_price !== undefined && Number.isFinite(Number(retail_price))) {
      resolvedRetailPrice = Number(retail_price);
    } else if (margin_percent !== undefined && Number.isFinite(Number(margin_percent))) {
      resolvedMarginPercent = Number(margin_percent);
      if (agentCostPer10 > 0) {
        resolvedRetailPrice = agentCostPer10 * (1 + resolvedMarginPercent / 100);
      }
    }

    const maxMargin = Number((check.products as any)?.max_margin_percent || 300);
    // Admin store price = the hard price ceiling for all agents.
    const maxRetailPrice: number | null = (check.products as any)?.max_retail_price != null
      ? Number((check.products as any).max_retail_price)
      : null;

    // Minimum-margin floor (platform rule): retail must be at least 10% above
    // the agent's cost - but never demand a price above the admin ceiling,
    // or an agent whose cost sits near the ceiling could not price at all.
    const minMarginFloor = Math.round(agentCostPer10 * 1.10 * 100) / 100;
    const effectiveFloor = maxRetailPrice != null ? Math.min(minMarginFloor, maxRetailPrice) : minMarginFloor;

    const minRetailPrice = Number((check.products as any)?.min_retail_price || effectiveFloor);

    // ── Pricing guardrails ─────────────────────────────────────────────
    // Manufacturers are EXEMPT from every floor, ceiling, and margin cap:
    // they set any price in either direction. (The DB-level ceiling trigger
    // has the same manufacturer bypass.)
    if (!isManufacturer) {
      if (resolvedRetailPrice !== undefined && resolvedRetailPrice < minRetailPrice) {
        return NextResponse.json(
          {
            error: `Listed price ($${(resolvedRetailPrice / 10).toFixed(2)}/vial) cannot be below the Minimum Advertised Price ($${(minRetailPrice / 10).toFixed(2)}/vial).`,
          },
          { status: 422 }
        );
      }

      if (resolvedRetailPrice !== undefined && resolvedRetailPrice < effectiveFloor) {
        return NextResponse.json(
          {
            error: `Retail Price Must Be At Least 10% Above Your Cost ($${(effectiveFloor / 10).toFixed(2)} Minimum).`,
          },
          { status: 422 }
        );
      }

      // Maximum price ceiling: agents may never exceed the admin store price.
      // Admins are exempt — they ARE the source of truth for max_retail_price.
      if (!gate.isAdmin && maxRetailPrice !== null && resolvedRetailPrice !== undefined && resolvedRetailPrice > maxRetailPrice) {
        return NextResponse.json(
          {
            error: `Listed price ($${(resolvedRetailPrice / 10).toFixed(2)}/vial) exceeds the maximum allowed price ($${(maxRetailPrice / 10).toFixed(2)}/vial). Agents may not price above the admin store rate.`,
          },
          { status: 422 }
        );
      }

      // The margin ceiling protects the marketplace from agent price gouging.
      // It does NOT apply to the admin house store: the admin's cost basis is
      // raw COGS (base_cost), so healthy retail prices are naturally far above
      // 300% of cost.
      if (!gate.isAdmin && !marginCapExempt && resolvedMarginPercent !== undefined && resolvedMarginPercent > maxMargin) {
        return NextResponse.json(
          {
            error: `Requested margin (${resolvedMarginPercent}%) exceeds the platform maximum of ${maxMargin}%.`,
          },
          { status: 422 }
        );
      }
    }

    if (!isManufacturer && retail_price !== undefined && Number.isFinite(Number(retail_price)) && agentCostPer10 > 0) {
      resolvedMarginPercent = Math.round((resolvedRetailPrice! / agentCostPer10 - 1) * 100 * 100) / 100;
    }

    const activeSalePrice = sale_price !== undefined && sale_price !== null ? sale_price : Number(check.sale_price);
    const activeIsOnSale = is_on_sale !== undefined ? Boolean(is_on_sale) : Boolean(check.is_on_sale);

    // Fail closed: the MAP/cost floors run whenever a sale price is being
    // SET (not only when the sale is currently active) so a below-floor
    // value can never be parked on the row and switched on later. A
    // non-finite stored value also refuses to activate.
    const salePriceBeingSet = sale_price !== undefined && sale_price !== null;
    if (activeIsOnSale && !Number.isFinite(activeSalePrice)) {
      return NextResponse.json(
        { error: 'Sale Price Must Be A Valid Number Before The Sale Can Be Activated.' },
        { status: 422 }
      );
    }
    if (!isManufacturer && (activeIsOnSale || salePriceBeingSet)) {
      if (!(activeSalePrice >= minRetailPrice)) {
        return NextResponse.json(
          {
            error: `Sale price ($${(activeSalePrice / 10).toFixed(2)}/vial) cannot be below the Minimum Advertised Price ($${(minRetailPrice / 10).toFixed(2)}/vial).`,
          },
          { status: 422 }
        );
      }

      if (!(activeSalePrice >= effectiveFloor)) {
        return NextResponse.json(
          {
            error: `Retail Price Must Be At Least 10% Above Your Cost ($${(effectiveFloor / 10).toFixed(2)} Minimum).`,
          },
          { status: 422 }
        );
      }

      // Sale price ceiling — cannot exceed admin store max either.
      if (!gate.isAdmin && maxRetailPrice !== null && activeSalePrice > maxRetailPrice) {
        return NextResponse.json(
          {
            error: `Sale price ($${(activeSalePrice / 10).toFixed(2)}/vial) exceeds the maximum allowed price ($${(maxRetailPrice / 10).toFixed(2)}/vial).`,
          },
          { status: 422 }
        );
      }
    }

    const checkRetailPrice = activeIsOnSale ? activeSalePrice : (resolvedRetailPrice !== undefined ? resolvedRetailPrice : Number(check.retail_price));
    if (!isManufacturer && checkRetailPrice > 0 && agentCostPer10 > 0) {
      const newMarginPct = ((checkRetailPrice - agentCostPer10) / checkRetailPrice) * 100;

      const { data: subAgents } = await supabase
        .from('profiles')
        .select('commission_pct, commission_max_pct')
        .eq('parent_agent_id', gate.user.id)
        .eq('is_sub_agent', true);

      if (subAgents && subAgents.length > 0) {
        let maxExisting = 0;
        for (const sa of subAgents) {
          const val = Math.max(Number(sa.commission_pct || 0), Number(sa.commission_max_pct || 0));
          if (val > maxExisting) maxExisting = val;
        }

        if (maxExisting > 0) {
          const netMarginPct = newMarginPct - maxExisting;

          if (netMarginPct < 10) {
            const minRequiredGross = maxExisting + 10;
            return NextResponse.json(
              { error: `Cannot lower price to $${((checkRetailPrice / 10).toFixed(2))}/vial. You have sub-agents earning up to ${maxExisting}% commission, which requires this product's margin to be at least ${minRequiredGross}% to maintain a 10% Net Profit.` },
              { status: 422 }
            );
          }

          if (maxExisting > netMarginPct) {
            import('@/lib/notify').then(async ({ notifyMarginWarning }) => {
              const { createAdminClient } = await import('@/lib/supabase/server');
              const admin = createAdminClient();
              notifyMarginWarning(admin, gate.user.id).catch((err: Error) => {
                console.error('[products/route] Failed to fire margin warning:', err);
              });
            });
          }
        }
      }
    }

    if (custom_name !== undefined && typeof custom_name === 'string' && custom_name.length > 200) {
      return NextResponse.json({ error: 'Custom Name Too Long (Max 200)' }, { status: 400 });
    }
    if (custom_description !== undefined && typeof custom_description === 'string' && custom_description.length > 5000) {
      return NextResponse.json({ error: 'Custom Description Too Long (Max 5,000)' }, { status: 400 });
    }
    if (custom_image_url !== undefined && typeof custom_image_url === 'string' && custom_image_url.length > 500) {
      return NextResponse.json({ error: 'Custom Image URL Too Long (Max 500)' }, { status: 400 });
    }

    const updatePayload: Record<string, unknown> = {
      custom_name: custom_name !== undefined ? (custom_name || null) : undefined,
      custom_description: custom_description !== undefined ? (custom_description || null) : undefined,
      custom_image_url: custom_image_url !== undefined ? (custom_image_url || null) : undefined,
      is_visible: is_visible !== undefined ? Boolean(is_visible) : undefined,
      is_on_sale: is_on_sale !== undefined ? Boolean(is_on_sale) : undefined,
      sale_price: sale_price !== undefined ? (sale_price ?? null) : undefined,
      updated_at: new Date().toISOString(),
    };

    // manufacturer_cost is the manufacturer's own private production cost per
    // 10-pack (profit display input). Only a manufacturer may write it.
    if (manufacturer_cost !== undefined) {
      if (!isManufacturer) {
        return NextResponse.json(
          { error: 'Only Manufacturer Accounts Can Set A Manufacturer Cost.' },
          { status: 403 }
        );
      }
      updatePayload.manufacturer_cost = manufacturer_cost ?? null;
    }

    Object.keys(updatePayload).forEach(k => updatePayload[k] === undefined && delete updatePayload[k]);

    if (resolvedRetailPrice !== undefined) {
      updatePayload.retail_price = resolvedRetailPrice;
      if (resolvedMarginPercent !== undefined) {
        updatePayload.margin_percent = resolvedMarginPercent;
      }
    } else if (resolvedMarginPercent !== undefined) {
      updatePayload.margin_percent = resolvedMarginPercent;
    }

    const { error } = await supabase
      .from('agent_products')
      .update(updatePayload)
      .eq('id', id)
      .eq('agent_id', gate.user.id);

    if (error) {
      return NextResponse.json({ error: 'An Unexpected Error Occurred.' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('[agent/products] PATCH error:', err);
    return NextResponse.json({ error: 'An Unexpected Error Occurred.' }, { status: 500 });
  }
}
